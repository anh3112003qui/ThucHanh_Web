<html lang="en">

<head>
     <meta charset="UTF-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <meta name="viewport" content="width=device-width, initial-scale=1.0" />
     <title>Document</title>
</head>

<body>

     <form method="get" action="#">
          <input type="input" name="chieudai" placeholder="chiều dài"><br><br>
          <input type="input" name="chieurong" placeholder="chiều rộng"><br><br>
          <input type="Submit" value="Tính" name="Submit">
     </form>

     <?php
          if(isset($_GET['Submit'])&&($_GET['Submit']=="Tính"))
          {
               $length= test_input($_GET['chieudai']);
               $width= test_input($_GET['chieurong']);
               $dai = (float)$length;
               $rong = (float)$width;

               if(!((float)$dai && (float)$rong)){
                    echo"
                         <script type=\"text/javascript\">
                         alert('Chiều dài và chiều rộng phải là số nguyên hoặc số thực. Bạn vui lòng nhập lại!');
                         </script>
                    ";
               }
               else if($dai <= 0 || $rong <= 0){
                    echo"
                         <script type=\"text/javascript\">
                         alert('Chiều dài và chiều rộng phải >= 0. Bạn vui lòng nhập lại!');
                         </script>
                    ";
               }
               else if($dai < $rong){
                    echo"
                         <script type=\"text/javascript\">
                         alert('Chiều dài phải lớn hơn chiều rộng. Bạn vui lòng nhập lại!');
                         </script>
                    ";
               }
               else{
                    $dientich = $dai * $rong;
                    $chuvi = ($dai + $rong) * 2;
                    echo "Diện tích: ".$dientich."<br>";
                    echo "Chu vi: ".$chuvi;
               }
          }

          function test_input($data) {
               $data = trim($data);        // loại bỏ các kí tự thừa (khoảng trắng, tab, dòng mới) khỏi input
               $data = stripslashes($data);    // xóa dấu gạch chéo ngược (backslashes \) khỏi input
               $data = htmlspecialchars($data);    // ngăn chặn người dùng nhập vào các trường dữ liệu không hợp lệ (như sql injection, URL, ...)
               return $data;
           }
     ?>

</body>

</html>