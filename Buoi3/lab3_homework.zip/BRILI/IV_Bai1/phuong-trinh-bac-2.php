<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="phuong-trinh-bac-2-form.css">
</head>
<body>
    <form method="GET" id="phuongTrinhBac2" action="phuong-trinh-bac-2.php">
        <table>
            <tr>
                <td>Hệ số a</td>
                <td><input type="number" id="heSoA" name="heSoA"><br><br></td>
            </tr>
            <tr>
                <td>Hệ số b</td>
                <td><input type="number" id="heSoB" name="heSoB"><br><br></td>
            </tr>
            <tr>
                <td>Hệ số c</td>
                <td><input type="number" id="heSoC" name="heSoC"><br><br></td>
            </tr>
            <tr  >
                <td colspan="2" id="giaiButton" >
                    <button type="submit" form="phuongTrinhBac2" value="Giải" name="Giải">Giải</button>
                </td>
            </tr>
        </table>
    </form>
    <?php
    if(isset($_GET["Giải"])&&($_GET["Giải"]=="Giải"))
    {
        $heSoA=$_GET["heSoA"];
        $heSoB=$_GET["heSoB"];
        $heSoC=$_GET["heSoC"];
        $dapAn=1;
        $nghiem1;
        $nghiem2;
        $delta=$heSoB*$heSoB - 4*$heSoA*$heSoC;

        if ($heSoA==0){
            echo "Tham số a không thoả";
            exit();
        }
        else {
            
            if ($delta<0){
                $dapAn=0;
            }
            else if ($delta==0) {
                $dapAn=1;
            }
            else {              
                $dapAn=2;               
            }
        }

        switch ($dapAn) {
            case 1:
                $nghiem1=-$heSoB/(2*$heSoA);
                $nghiem1= number_format($nghiem1, 2, '.', '');
                echo "Phương trình có 1 nghiệm là: $nghiem1 ";
                break;
            case 2:
                $nghiem1=(-$heSoB + sqrt($delta) ) / (2*$heSoA) ;
                $nghiem1= number_format($nghiem1, 2, '.', '');
                $nghiem2=(-$heSoB - sqrt($delta) ) / (2*$heSoA) ;
                $nghiem2= number_format($nghiem2, 2, '.', '');
                
                echo "Phương trình có nghiệm thứ nhất: $nghiem1 <br>\n"; 
                echo "Phương trình có nghiệm thứ hai: $nghiem2";
              break;
            default:
                echo "Phương trình vô nghiệm";
                break;
          }


    }
?>

</body>
</html>

