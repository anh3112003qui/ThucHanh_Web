<!DOCTYPE html>
    <body>
        <form method="GET" action="./bangdiem.php">
            <div style="background-color: #FDCDCC; width:30%; margin: auto; border: 1px solid">
                <h1><center> Đăng nhập hệ thống xem điểm </center></h1>
                <table align="center" cellspacing="0">
                    <tr><td>Tên đăng nhập </td><td><input type="input" name="tendangnhap"></td></tr>
                    <tr><td>Mật khẩu </td><td><input type="input" name="matkhau"></td></tr>
                    <tr><td colspan="2" align="center"><input style="border-radius: 8px" type="Submit" value="Đăng nhập" name="dangnhapbtn"></td></tr>
                </table>
            </div>
        </form>
    </body>
</html>