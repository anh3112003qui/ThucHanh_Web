<?php
include_once 'ClassSachTieuThuyet.php';
include_once 'ClassSachTrinhTham.php';
include_once 'ClassSach.php';

$sachtt1 = new SachTieuThuyet(1,'Tiểu thuyết 1', 50000, 20, 'NXB 1', 'new');
$sachtt2 = new SachTieuThuyet(2,'Tiểu thuyết 2', 70000, 30, 'NXB 2', 'old');
$sachtt3 = new SachTieuThuyet(3,'Tiểu thuyết 3', 45000, 15, 'NXB 3', 'new');


$sachTrinhTham1 = new SachTrinhTham(4,'Sách trinh thám 1', 95000, 15, 'NXB 4',0.02);
$sachTrinhTham2 = new SachTrinhTham(5,'Sách trinh thám 2', 55000, 55, 'NXB 2',0.03);
$sachTrinhTham3 = new SachTrinhTham(6,'Sách trinh thám 3', 75000, 35, 'NXB 4',0.025);

$sachArray = array($sachtt1, $sachtt2, $sachtt3, $sachTrinhTham1,$sachTrinhTham2, $sachTrinhTham3);

$soLuongTieuThuyet =0;
$tongTienTieuThuyet = 0;
$tongTienTrinhTham =0;
$soLuongTrinhTham =0;
for($i=0; $i< count($sachArray); $i++){
    if(strcasecmp($sachArray[$i]->getLoaiSach(), 'tiểu thuyết') ==0){
        $soLuongTieuThuyet+=$sachArray[$i]->getSoLuong();
        $tongTienTieuThuyet += $sachArray[$i]->tinhTienSach();
    }
    else {
        $soLuongTrinhTham +=$sachArray[$i]->getSoLuong();
        $tongTienTrinhTham += $sachArray[$i]->tinhTienSach();
    }
}
echo "Số lượng sách tiểu thuyết là: ".$soLuongTieuThuyet."<br>";
echo "Tổng tiền sách tiểu thuyết là: ".$tongTienTieuThuyet."<br>";
echo "----------------------------------------------------------------------------<br>";

echo "Số lượng sách trinh thám là: ".$soLuongTrinhTham."<br>";
echo "Tổng tiền sách trinh thám là: ".$tongTienTrinhTham."<br>";
echo "----------------------------------------------------------------------------<br>";
?>