<?php
include_once 'ClassSach.php';

class SachTieuThuyet extends Sach{
    protected $tinhTrang;

    public function __construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan, $tinhTrang)
    {
        parent::__construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan);
        $this->loaiSach = 'tiểu thuyết';
        $this->tinhTrang = $tinhTrang;
    }
    public function getTinhTrang(){
        return $this->tinhTrang;
    }
    public function setTinhTrang($tinhTrang){
        $this->tinhTrang = $tinhTrang;
    }
    public function tinhTienSach()
    {
        if(strcasecmp($this->tinhTrang, 'old') == 0){
            return ($this->donGia * $this->soLuong *0.2) ;
        }
        elseif(strcasecmp($this->tinhTrang, 'new') == 0){
            return ($this->donGia *$this->soLuong);
        }
    }
}
?>