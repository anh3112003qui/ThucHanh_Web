<?php
class Sach{
    protected $maSach;
    protected $tenSach;
    protected $donGia;
    protected $soLuong;
    protected $nhaXuatBan;
    protected $loaiSach;
    
    public function __construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan){
        $this ->maSach = $maSach;
        $this ->tenSach = $tenSach;
        $this ->donGia = $donGia;
        $this ->soLuong = $soLuong;
        $this ->nhaXuatBan = $nhaXuatBan;
    }
    
    public function getMaSach(){
        return $this ->maSach;
    }
    public function setMaSach($maSach){
        $this->maSach = $maSach;
    }

    public function getTenSach(){
        return $this ->tenSach;
    }
    public function setTenSach($tenSach){
        $this->tenSach = $tenSach;
    }

    public function getDonGia(){
        return $this ->donGia;
    }
    public function setDonGia($donGia){
        $this->donGia = $donGia;
    }

    public function getSoLuong(){
        return $this ->soLuong;
    }
    public function setSoLuong($soLuong){
        $this->soLuong = $soLuong;
    }

    public function getNhaXuatBan(){
        return $this ->nhaXuatBan;
    }
    public function setNhaXuatBan($nhaXuatBan){
        $this->nhaXuatBan = $nhaXuatBan;
    }
    
    public function getLoaiSach(){
        return $this ->loaiSach;
    }
    public function setLoaiSach($loaiSach){
        $this->loaiSach = $loaiSach;
    }

    //Phuong thuc tinh tien sach
    public function tinhTienSach(){
        return;
    }
}
?>