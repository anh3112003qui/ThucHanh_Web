<?php
include_once 'ClassSach.php';

class SachTrinhTham extends Sach{
    protected $thue;

    public function __construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan, $thue)
    {
        parent::__construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan,  $thue);
        $this->loaiSach = 'trinh thám';
        $this->thue = $thue;
    }
    public function getThue(){
        return $this->thue;
    }
    public function setThue($thue){
        $this->thue = $thue;
    }
    // tinh tien sach
    public function tinhTienSach()
    {
        return $this->soLuong *$this->donGia *$this->thue;
    }
}
?>