<?php
    class TaiKhoan {
        private $soTK, $tenTK, $soTien;

        public function TaiKhoan() {
            $this->soTK = 0;
            $this->tenTK = null;
            $this->soTien = 10;
        }

        public function __construct($soTaiKhoan, $tenTaiKhoan, $soTienTaiKhoan) {
            $this->soTK = $soTaiKhoan;
            $this->tenTK = $tenTaiKhoan;
            $this->soTien = $soTienTaiKhoan;
        }

        public function InTaiKhoan(){
            echo "Số tài khoản: ".$this->soTK."<br>";
            echo "Tên tài khoản: ".$this->tenTK."<br>";
            echo "Số dư: ".$this->soTien." USD"."<br>";
        }

        public function NapTien($st) {
            if ($st >0){
                $this->soTien=$this->soTien + $st;
                return true;
            }
            return false;
        }


        public function RutTien($ts) {
            if ($ts >0 && $this->soTien>$ts ){
                $this->soTien= $this->soTien - $ts - 0.01*$ts;
                return true;
            }
            return false;
        }
   }
?>