<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="question-4.css">
</head>

<body>

    <form method="GET" id="taiKhoan" action="#">
        <table>
            <tr>
                <td>Nạp tiền</td>
                <td><input type="number" id="napTien" name="napTien"><br><br></td>
                <td><button type="submit" form="taiKhoan" value="NapTien" name="NapTien">Nạp tiền</button></td>
            </tr>
            <tr>
                <td>Rút tiền</td>
                <td><input type="number" id="rutTien" name="rutTien"><br><br></td>
                <td><button type="submit" form="taiKhoan" value="RutTien" name="RutTien">Rút tiền</button></td>
            </tr>
        </table>
    </form>

    <?php
    include "TaiKhoan.php";
    $taiKhoan = new TaiKhoan(123, "Brili", 1000);
    $taiKhoan->InTaiKhoan();

    if (isset($_GET["NapTien"]) && ($_GET["NapTien"] == "NapTien")) {
        $tienNap = $_GET["napTien"];
        if ($taiKhoan->NapTien($tienNap) == true) {
            $taiKhoan->InTaiKhoan();
        } else
            echo "Số tiền không hợp lệ!";
    }

    if (isset($_GET["RutTien"]) && ($_GET["RutTien"] == "RutTien")) {
        $tienRut = $_GET["rutTien"];
        if ($taiKhoan->RutTien($tienRut) == true) {
            echo "Phí rút: " . 0.01*$tienRut." USD"."<br>";
            $taiKhoan->InTaiKhoan();
        } else
            echo "Số tiền không hợp lệ!";
    }



    ?>
</body>

</html>