<?php
    $dateSelect = $_POST['$dateSelect'];
    $dateBegin = $_POST['$dateBegin'];

    $arr1 = explode('-', $dateBegin);
    $arr2 = explode('-', $dateSelect);

    include "ngay.php";
    $dateFrom = new ngay ($arr1[2], $arr1[1], $arr1[0]);
    $dateTo = new ngay ($arr2[2], $arr2[1], $arr2[0]);
    $numOfDay = $dateTo->SoThuTu() - $dateFrom->SoThuTu();
    echo $numOfDay;
?>