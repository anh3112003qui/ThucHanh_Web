var now = new Date();
var day = ("0" + now.getDate()).slice(-2);
var month = ("0" + (now.getMonth() + 1)).slice(-2);
var today = now.getFullYear() + "-" + month + "-" + day;

document.getElementById('start-date').value = today;

// Xử lý input khi người dùng thay đổi ngày đích
$(document).ready(function(){
    $('#date-input').on('change', function handler(e){
        e.preventDefault();
        var $dateInput = $(this).val(); // this.value
        var $startDate = document.getElementById('start-date').value;
        
        $.ajax({
            url: 'xuly.php',
            type: 'POST',
            dataType: 'html',
            data: {$dateSelect: $dateInput,
                    $dateBegin: $startDate}
        }).done(function(ketqua){
            if (ketqua < 0) {
                $('.result').html('');
                alert ("Ngày nguồn phải nhỏ hơn hoặc bằng ngày đích");
            }
            else {
                $('.result').html(ketqua);
            }
            
        });
    })
})