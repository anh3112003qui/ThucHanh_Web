<?php
    class ngay {
        public $ngay, $thang, $nam;
        public function __construct($date, $month, $year) {
        $this->ngay = $date;
        $this->thang = $month;
        $this->nam = $year;
        }

        public function ktNhuan() {
            if (($this->nam %4 == 0 && $this->nam % 100 != 0) || $this->nam %400 == 0) 
                return 1;
            return 0;
        }

        public function SoNgayToiDaTrongThang() {
            $ngaythang = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
            if ($this->ktNhuan()) {
                $ngaythang[1] = 29;
            }
            return $ngaythang[$this->thang - 1];
        }

        public function SoNgayToiDaTrongNam() {
            if ($this->ktNhuan()) {
                return 366;
            }
            return 365;
        }

        public function SoThuTuTrongNam() {
            $stt = 0;
            for ($i = 1; $i <= $this->thang - 1; $i++) {
                $temp = new ngay(1, $i, $this->nam);
                $stt = $stt +  $temp->SoNgayToiDaTrongThang();
            }
            return ($stt + $this->ngay);
        }

        public function SoThuTu() {
            $stt = 0;
            for ($i = 1; $i <= $this->nam - 1; $i++) {
                $temp = new ngay(1, 1, $i);
                $stt = $stt + $temp->SoNgayToiDaTrongNam();
            }
            return ($stt + $this->SoThuTuTrongNam());
        }

        public function TimNgayTrongNam($nam, $stt) {
            $temp = new ngay(1, 1, $nam);
            $temp->thang = 1;
            while ($stt - $temp->SoNgayToiDaTrongThang() > 0) {
                $stt = $stt - $temp->SoNgayToiDaTrongThang();
                $temp->thang++;
            }
            $temp->ngay = $stt;
            return $temp;
        }

        public function TimNgay($stt) {
            $nam = 1;
            $sn = 365;
            while ($stt - $sn > 0) {
                $stt = $stt - $sn;
                $nam++;

                $temp = new ngay(1, 1, $nam);
                $sn = $temp->SoNgayToiDaTrongNam();
            }
            return $this->TimNgayTrongNam($nam, $stt);
        }

        public function KeTiep() {
            $stt = $this->SoThuTu();
            $stt++;
            return $this->TimNgay($stt);
        }
    }
?>