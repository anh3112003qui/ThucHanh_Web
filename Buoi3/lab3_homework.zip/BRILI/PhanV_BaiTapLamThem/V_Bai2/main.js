var now = new Date();
var thisYear = now.getFullYear();
document.getElementById('year-select').value = thisYear;

// Bắt sự kiện từ input và load lên combobox số ngày trong tháng năm đó
$(document).ready(function(){
    $('#month-select').on('change', function handler(e){
        e.preventDefault();
        var $monthSelected = document.getElementById('month-select').value;
        var $yearSelected = document.getElementById('year-select').value;

        $.ajax({
            url: 'xuLyLoadCombobox.php',
            type: 'POST',
            dataType: 'html',
            data: {$month: $monthSelected,
                    $year: $yearSelected}
        }).done(function(ketqua){
            var dateSelect = document.getElementById('date-select');
            for (let i = 1; i <= ketqua; i++) {
                
                var option = document.createElement('option');
                option.text = i;
                dateSelect.add(option);
            }
            dateSelect.visible = true;
        });
    })
});


$(document).ready(function(){
    $('#year-select').on('blur', function load_date(e){
        e.preventDefault();
        var $monthSelected = document.getElementById('month-select').value;
        var $yearSelected = document.getElementById('year-select').value;

        $.ajax({
            url: 'xuLyLoadCombobox.php',
            type: 'POST',
            dataType: 'html',
            data: {$month: $monthSelected,
                    $year: $yearSelected}
        }).done(function(ketqua){
            for (let i = 1; i <= ketqua; i++) {
                var dateSelect = document.getElementById('date-select');
                var option = document.createElement('option');
                option.text = i;
                dateSelect.add(option);
            }
        });
    })
});


$(document).ready(function(){
    $('#next-btn').on('click', function displayNextDay(e){
        e.preventDefault();
        var $monthSelected = document.getElementById('month-select').value;
        var $yearSelected = document.getElementById('year-select').value;
        var $myDaySelect = document.getElementById('date-select');
        var $dateSelected = $myDaySelect.options[$myDaySelect.selectedIndex].text;

        $.ajax({
            url: 'xuLyLoadKetQua.php',
            type: 'POST',
            dataType: 'html',
            data: {$thisDate: $dateSelected,
                    $thisMonth: $monthSelected,
                    $thisYear: $yearSelected}
        }).done(function(ketqua){
            arr = [ketqua.split('*')];
            console.log(arr);
            $('.result').html(`Ngày kế tiếp của ngày ${$dateSelected} tháng ${$monthSelected} năm ${$yearSelected} là ` + 
                                        `ngày ${arr[0][0]} tháng ${arr[0][1]} năm ${arr[0][2]}`);
        });
    })
})