<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>V. 2.Tìm ngày kế tiếp</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <form action="" method="GET" class="nextday-form" onsubmit="return false">
        <label for="month-select">Tháng</label>
        <input type="number" name="month-select" id="month-select" min="1" max="12" step="1" value="11" onchange="handler(event)">
        <label for="year-select">Năm</label>
        <input type="text" name="year-select" id="year-select" maxlength="4" >
        <label for="">Ngày</label>
        <select name="date-select" id="date-select"></select>
        
        <div>
            <input type="submit" value="Next" id="next-btn" onclick="displayNextDay(event)">
        </div>
        <div>
            <p class="result"></p>
        </div>
    </form>

    <script src="./main.js"></script>
</body>
</html>