<?php
    $month = $_POST['$month'];
    $year = $_POST['$year'];
    include "ngay.php";
    $tempDate = new ngay(1, $month, $year);
    $soNgay = $tempDate->SoNgayToiDaTrongThang();
    echo $soNgay;
?>