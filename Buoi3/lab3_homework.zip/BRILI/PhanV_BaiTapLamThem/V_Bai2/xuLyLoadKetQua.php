<?php
    $thisDate = $_POST['$thisDate'];
    $thisMonth = $_POST['$thisMonth'];
    $thisYear = $_POST['$thisYear'];
    include "ngay.php";
    $tempDate = new ngay($thisDate, $thisMonth, $thisYear);
    $date = $tempDate->KeTiep();
    echo "$date->ngay*$date->thang*$date->nam";

?>