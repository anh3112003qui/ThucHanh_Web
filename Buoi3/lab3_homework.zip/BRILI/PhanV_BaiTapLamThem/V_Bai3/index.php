<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method='GET' action="#">
        <table>
            <tr>
                <td>Ngày</td>
                <td><input name='input-date' type="text" value="<?php echo isset($_GET['input-day']) ? $_GET['input-day'] : '' ?>"></td>
            </tr>
            <tr>
                <td>Tháng</td>
                <td><input name='input-month' type="text" value="<?php echo isset($_GET['input-month']) ? $_GET['input-month'] : '' ?>"></td>
            </tr>
            <tr>
                <td>Năm</td>
                <td><input name='input-year' type="text" value="<?php echo isset($_GET['input-year']) ? $_GET['input-year'] : '' ?>"></td>
            </tr>
            <tr>
                <td colspan="2" class='btn-submit'>
                    <input type="submit" name="print-btn" value='In thứ'>
                </td>
            </tr>
        </table>
    </form>

    <?php
        include "ngay.php";
        if (isset($_GET['print-btn']) && $_GET['print-btn'] == 'In thứ') {
            $date = test_input($_GET['input-date']); 
            $month = test_input($_GET['input-month']); 
            $year = test_input($_GET['input-year']);
            $newDate = new ngay($date, $month, $year);
            $dayOfWeek = $newDate->XuatThu();
            echo $dayOfWeek." ngày ".$date." tháng ".$month." năm ".$year;
        }

        function test_input($data) {
            $data = trim($data);        // loại bỏ các kí tự thừa (khoảng trắng, tab, dòng mới) khỏi input
            $data = stripslashes($data);    // xóa dấu gạch chéo ngược (backslashes \) khỏi input
            $data = htmlspecialchars($data);    // ngăn chặn người dùng nhập vào các trường dữ liệu không hợp lệ (như sql injection, URL, ...)
            return $data;
        }
    ?>
</body>
</html>